---
layout: default
title: "CV"
permalink: /cv/
---

# Curriculum Vitae

Download my CV [here](/assets/cv.pdf).

## Education
- Ph.D. in Applied Mathematics, IIT Bombay
- M.Sc., IIT Kanpur
