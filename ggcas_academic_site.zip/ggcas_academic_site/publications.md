---
layout: default
title: "Publications"
permalink: /publications/
---

# Publications

1. GG Cas, A. Author. *A Study on Parareal Methods*. (2024)
