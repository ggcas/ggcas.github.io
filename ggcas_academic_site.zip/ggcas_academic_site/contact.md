---
layout: default
title: "Contact"
permalink: /contact/
---

# Contact

📧 ggcas@university.edu  
🏛 University of XYZ  
📍 City, Country
