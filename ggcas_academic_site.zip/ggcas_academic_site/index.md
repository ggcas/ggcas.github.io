---
layout: default
title: "Home"
---

# Welcome

I’m Dr. GG Cas, a postdoctoral researcher in Applied Mathematics.

My research interests include:

- Domain Decomposition
- Parallel-in-Time Methods
- PDE-Constrained Optimization

📄 [Download my CV](/assets/cv.pdf)  
📧 ggcas@university.edu  
🏛 Department of Mathematics
